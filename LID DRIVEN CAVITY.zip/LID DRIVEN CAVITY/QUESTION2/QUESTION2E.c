
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
void main(){
   int m=21,n=21,i,j;
   float dx=1.0/(m-1);
    float dy=1.0/(n-1);


    float mat1[m][n],mat2[m][n],temp,p[m],q[m],d[m],d_[n],p_[n],q_[n];

    float as,aw,ap,ae,an,ai,bi,ci,aj,bj,cj;
    as=(1.0/pow(dy,2.0));
    aw=(1.0/pow(dx,2.0));
    ap=2.0*((1.0/pow(dx,2.0))+(1.0/pow(dy,2.0)));
    ae=(1.0/pow(dx,2.0));
    an=(1.0/pow(dy,2.0));
    ai=ap;
    bi=-ae;
    ci=-aw;
     aj=ap;
    bj=-an;
    cj=-as;

    for(i=0; i<m; i++){
            for(j=0; j<n; j++){
                 if (j==0){
                    mat2[i][j]=1.0;      //bottom boundary
                }
                else if (j==(n-1)){
                    mat2[i][j]=0.0;      //top boundary
                }
                else if (i==0){
                    mat2[i][j]=1.0;      //left boundary
                }
                else if (i==(m-1)){
                    mat2[i][j]=1.0;       //right boundary
                }
                else{
                    mat2[i][j]=0.0;
                }
            }
        }
           int iteration = 0;
    double error=1.0;
    FILE *f1;
    f1=fopen("error2e.dat","w");
    do{
             for(i=0; i<m; i++){
         for(j=0; j<n; j++){
          mat1[i][j]= mat2[i][j];

      }
}

      error=0.0;
         for(j=1; j<n-1; j++){
                d[0]=an*(mat2[0][j+1]+mat2[0][j-1]);
              p[0]=-bi/ai;
              q[0]=d[0]/ai;

            for(i=1; i<m-1; i++){
                  d[i]=an*(mat2[i][j+1]+mat2[i][j-1]);

                   p[i]=-(bi/(ai+ci*p[i-1]));
                   q[i]=(d[i]-ci*q[i-1])/(ai+ci*p[i-1]);

            }
             for(i=m-2; i>0; i--){
               mat2[i][j]=p[i]*mat2[i+1][j]+q[i];
              }
            }
            for(i=1; i<m-1; i++){
              d_[0]=ae*(mat2[i+1][0]+mat2[i-1][0]);
              p_[0]=-(bj/aj);

              q_[0]=(d_[0])/aj;

                   for(j=1; j<n-1; j++){
                  d_[j]=ae*(mat2[i+1][j]+mat2[i-1][j]);

                  p_[j]=-(bj/(aj+cj*p_[j-1]));

                  q_[j]=(d_[j]-cj*q_[j-1])/(aj+cj*p_[j-1]);

            }
             for(j=n-2; j>0; j--){

                mat2[i][j]=p_[j]*mat2[i][j+1]+q_[j];


         }
    }

       for(i=0; i<m; i++){
            for(j=0; j<n; j++){
            error+=pow((mat2[i][j]-mat1[i][j]),2);
        }
    }


       error=sqrt(error/((m-2)*(n-2)));
      printf("iteration %d\t",iteration);
      printf("error %.9f\n",error);
      fprintf(f1,"%d\t%lf\n",iteration,error);
      iteration++;
      }while(error > 1e-6);
      double x[m],y[n];
x[0]=0.0; y[0]=0.0;

for(j = 0; j < n; j++)
{ y[j+1]=y[j]+dy;
}
for(i = 0; i < m; i++)
{ x[i+1]=x[i]+dx;
}
FILE *f2;
f2=fopen("2e_ADI.dat","w");
fprintf(f2,"Variable=\"X\",\"Y\",\"T\"\n",n,m);
fprintf(f2,"\tI=%d\tJ=%d\n",m,n);
for(i = 0; i < m; i++)  {
        for(j = 0; j < n; j++)
{
    fprintf(f2,"%lf\t%lf\t%lf\n",x[i],y[j],mat2[i][j]);

 }
} fclose(f2);
}
