#include<stdio.h>
#include<stdlib.h>
#include<math.h>

void main(){
   int m=21; int n=21,i,j;
   float dx=1.0/(m-1);
   float dy=1.0/(n-1);


    double mat[m][n],temp;

    double as,aw,ap,ae,an;
    as=(1.0/pow(dy,2.0));
    aw=(1.0/pow(dx,2.0));
    ap=2.0*((1.0/pow(dx,2.0))+(1.0/pow(dy,2.0)));
    ae=(1.0/pow(dx,2.0));
    an=(1.0/pow(dy,2.0));
    printf("%lf\t%lf\t%lf\t%lf\t%lf\n",ae,aw,an,as,ap);
    for(i=0; i<m; i++){
            for(j=0; j<n; j++){
                 if (j==0){
                    mat[i][j]=1.0;      //bottom boundary
                }
                else if (j==(n-1)){
                    mat[i][j]=0.0;      //top boundary
                }
                else if (i==0){
                    mat[i][j]=1.0;      //left boundary
                }
                else if (i==(m-1)){
                    mat[i][j]=1.0;       //right boundary
                }
                else{
                    mat[i][j]=0.0;
                }
            }
        }
         int iteration = 0;
    double error=1.0;
    FILE *f1;
    f1=fopen("pointgausserror2.dat","w");
    do{

      error=0.0;

      for(i=1; i<(m-1); i++){
        for(j=1; j<(n-1); j++){
                temp=mat[i][j];
                mat[i][j]=(1.0/ap)*(as*mat[i][j-1]+aw*mat[i-1][j]+ae*mat[i+1][j]+an*mat[i][j+1]);
                     error=error+pow((mat[i][j]- temp),2.0);

        }
      }

      error=sqrt(error/((m-2)*(n-2)));
      iteration=iteration+1;
      printf("iteration %d\t",iteration);
      printf("error %.9f\n",error);
      fprintf(f1,"%d\t%f\n",iteration,error);

      }while(error > 1e-6);

double x[m],y[n];
x[0]=0.0; y[0]=0.0;

for(j = 0; j < n; j++)
{ y[j+1]=y[j]+dy;
}
for(i = 0; i < m; i++)
{ x[i+1]=x[i]+dx;
}
FILE *f2;
f2=fopen("question_2b_gauss_seidel.dat","w");
fprintf(f2,"Variable=\"X\",\"Y\",\"PSI\"\n",n,m);
fprintf(f2,"\tI=%d\tJ=%d\n",m,n);
for(i = 0; i < m; i++)  {
        for(j = 0; j < n; j++)
{
    fprintf(f2,"%lf\t%lf\t%lf\n",x[i],y[j],mat[i][j]);
/* saving of psi values into file 0along with grids */
 }
} fclose(f2);
}
