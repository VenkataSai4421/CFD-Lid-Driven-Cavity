#include<stdio.h>
#include<stdlib.h>
#include<math.h>
void main()
{
    int m=21,n=21;
    int i,j;
    float x=1.0,y=1.0;
    double dx,dy;

    dx=x/(m-1);
    dy=y/(n-1);
    //defining two matrices to store psi new and old values
   float as,aw,ap,ae,an;
    float psi_old[m][n],psi_new[m][n];

    as=(1.0/pow(dy,2.0));
    aw=(1.0/pow(dx,2.0));
    ap=2*((1.0/pow(dx,2.0))+(1.0/pow(dy,2.0)));
    an=(1.0/pow(dy,2.0));
    ae=(1.0/pow(dx,2.0));
    //boundary condition initialization
     for(i=0; i<m; i++){
            for(j=0; j<n; j++){
                 if (j==0){
                    psi_new[i][j]=1.0;      //bottom boundary
                }
                else if (j==(n-1)){
                    psi_new[i][j]=0.0;      //top boundary
                }
                else if (i==0){
                    psi_new[i][j]=1.0;      //left boundary
                }
                else if (i==(m-1)){
                    psi_new[i][j]=1.0;       //right boundary
                }
                else{
                    psi_new[i][j]=0.0;
                }
            }
        }



//    jacobi iteration method
    int iteration=0;
    double error,error1;
    FILE *file1;
    file1=fopen("jacobi2error.dat","w"); //creating a file to write errors
    fprintf(file1,"iteration\t\error\n");
    do{
        for (int i=0;i<m;i++){
            for(int j=0;j<n;j++){
              psi_old[i][j]=psi_new[i][j]; //replacing old psi with new psi


            }
        }
       for(int i=1;i<(m-1);i++)
        {
            for(int j=1;j<(n-1);j++){
           psi_new[i][j] = (1.0/ap)*(aw*psi_old[i-1][j]+as*psi_old[i][j-1]+an*psi_old[i][j+1]+ae*psi_old[i+1][j]);
        }
        }

      error=0.0;
      for(i=1;i<(m-1);i++){
        for(j=1;j<(n-1);j++){
            error = error + pow((psi_new[i][j]-psi_old[i][j]),2.0);
        }
      }
      error = sqrt(error/((m-2)*(n-2)));
      printf("iteration %d\t\t",iteration);
      printf("error %.8f\n",error);
      fprintf(file1,"%d\t%.8f\n",iteration,error);
      iteration++;
    }
    while(error>1e-6);


FILE *file2;
    file2=fopen("ques2a.dat","w");
    fprintf(file2,"VARIABLES= \"X\",\"Y\",\"PHI\"\n");
    fprintf(file2, "ZONE t=\"BLOCK1\", J=21,I=21,F= POINT \n\n");

    for(int i=0; i<n ; i++){
            for(int j=0 ; j<m ; j++){
                fprintf(file2, "%lf \t %lf \t %lf \n",j*dy,i*dx,psi_new[j][i]);
            }
    }

}
