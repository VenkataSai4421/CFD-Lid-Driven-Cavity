#include<stdio.h>
#include<stdlib.h>
#include<math.h>
void main(){
   int m=21; int n=21;
   double dx=1.0/(m-1);
   double dy=1.0/(n-1);
   int i,j;

    double mat[m][n],temp,p[m],q[m],d[m];

    double as,aw,ap,ae,an,ai,bi,ci;
    as=(1.0/pow(dy,2.0));
    aw=(1.0/pow(dx,2.0));
    ap=2.0*((1.0/pow(dx,2.0))+(1.0/pow(dy,2.0)));
    ae=(1.0/pow(dx,2.0));
    an=(1.0/pow(dy,2.0));
    printf("%lf\t%lf\t%lf\t%lf\t%lf\n",ae,aw,an,as,ap);
    ai=ap;
    bi=-ae;
    ci=-aw;

    for(i=0; i<m; i++){
            for(j=0; j<n; j++){
                 if (j==0){
                    mat[i][j]=1.0;      //bottom boundary
                }
                else if (j==(n-1)){
                    mat[i][j]=0.0;      //top boundary
                }
                else if (i==0){
                    mat[i][j]=1.0;      //left boundary
                }
                else if (i==(m-1)){
                    mat[i][j]=1.0;       //right boundary
                }
                else{
                    mat[i][j]=0.0;
                }
            }
        }
           int iteration = 0;
    double error=1.0;
    FILE *f1;
    f1=fopen("tdmaerror2.dat","w");
    do{

      error=0.0;
         for(j=1; j<n-1; j++){
                d[0]=an*(mat[0][j+1]+mat[0][j-1]);
              p[0]=-bi/ai;
              q[0]=d[0]/ai;

            for(i=1; i<m-1; i++){
                  d[i]=an*(mat[i][j+1]+mat[i][j-1]);

                   p[i]=-(bi/(ai+ci*p[i-1]));
                   q[i]=(d[i]-ci*q[i-1])/(ai+ci*p[i-1]);

            }
             for(i=m-2; i>0; i--){
                temp=mat[i][j];
                mat[i][j]=p[i]*mat[i+1][j]+q[i];
              error+=pow((mat[i][j]- temp),2.0);

            }
            }

       error=sqrt(error/((m-2)*(n-2)));
      printf("iteration %d\t\t",iteration);
      printf("error %.9f\n",error);
      fprintf(f1,"%d\t%f\n",iteration,error);
      iteration++;
      }while(error > 1e-6);
      double x[m],y[n];
x[0]=0.0; y[0]=0.0;

for(j = 0; j < n; j++)
{ y[j+1]=y[j]+dy;
}
for(i = 0; i < m; i++)
{ x[i+1]=x[i]+dx;
}
FILE *f2;
f2=fopen("2d(TDMA).dat","w");
fprintf(f2,"Variable=\"X\",\"Y\",\"T\"\n",n,m);
fprintf(f2,"\tI=%d\tJ=%d\n",m,n);
for(i = 0; i < m; i++)  {
        for(j = 0; j < n; j++)
{
    fprintf(f2,"%lf\t%lf\t%lf\n",x[i],y[j],mat[i][j]);
/* saving of psi values into file 0along with grids */
 }
} fclose(f2);
}
