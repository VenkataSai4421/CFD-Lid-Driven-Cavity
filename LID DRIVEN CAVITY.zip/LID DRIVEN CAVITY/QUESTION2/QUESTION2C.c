#include<stdio.h>
#include<stdlib.h>
#include<math.h>
void main(){

       int m=21,n=21,i,j;
      float x=1.0,y=1.0;   //defining grid space
    float A_1[m][n],A_2[m][n],A_3[m][n];

    for(int i=0; i<m ; i++){
        for(int j=0 ; j<n ; j++){
                 if (j==0){
                    A_2[i][j]=1.0;      //bottom boundary
                }
                else if (j==(n-1)){
                    A_2[i][j]=0.0;      //top boundary
                }
                else if (i==0){
                    A_2[i][j]=1.0;      //left boundary
                }
                else if (i==(m-1)){
                    A_2[i][j]=1.0;       //right boundary
                }
                else{
                    A_2[i][j]=0.0;
                }
            }
        }

        float dx,dy;
         float b;
     dx=x/(m-1);
     dy=y/(n-1);

     b=pow((dx/dy),2);

          //point successive over relaxation method

           int iteration=0;
           double error;
          float a=pow(((cos(3.14/(m-1))+b*cos(3.14/(n-1)))/(1+(b*b))),2);
           float w=(2-sqrt(1-a))/a;
           FILE *error_file;
          error_file= fopen("psorerror2.dat","w");
            fprintf(error_file,"Iteration\t Error\n");
            FILE *countor;
             countor=fopen("Countor_2_point_successive.dat","w");
             fprintf(countor,"VARIABLES= \"X\",\"Y\",\"PHI\"\n");
                fprintf(countor, "ZONE t=\"BLOCK1\", J=21,I=21,F= POINT \n\n");

      do{

           for(int i=0;i<m;i++){
            for(int j=0;j<n;j++){
                A_1[i][j]=A_2[i][j];     //A_2=phi*  A_1=phik   A_3=phi(k+1)
                }
           }

          for(int i=1;i<m-1;i++){
            for(int j=1;j<n-1;j++){

          A_2[i][j]=(1/(2*(1+b)))*(b*A_2[i-1][j]+A_2[i][j-1]+A_1[i][j+1]+b*A_1[i+1][j]);
            }
          }


          for(int i=0;i<m;i++){
            for(j=0;j<n;j++){
          A_3[i][j]=A_1[i][j]+w*(A_2[i][j]-A_1[i][j]);
            }
          }

          error=0.0;
          for(int i=1;i<m-1;i++){
            for(int j=1;j<n-1;j++){
                error=error + pow((A_3[i][j]-A_2[i][j]),2);

            }
          }
          error=sqrt(error/((m)*(n)));
          iteration=iteration+1;
        printf("Iteration= %d\t", iteration);
        printf("Error= %.10lf\n", error);
        fprintf(error_file, "%d \t %.10lf \n", iteration, error);
    }
    while(error>1e-6);
printf("w=%lf",w);
    for(int i=0; i<n ; i++){
            for(int j=0 ; j<m ; j++){
                fprintf(countor, "%lf \t %lf \t %lf \n",j*dy,i*dx,A_3[j][i]);
            }
    }     

}
