#include<stdio.h>
#include<stdlib.h>
#include<math.h>
void main(){
   int m=31,n=21,i,j;
   float dx=6.0/(m-1);
  float dy=4.0/(n-1);

    float phi1[m][n], phi2[m][n],temp,p[m],q[m],d[m],d2[n],p2[n],q2[n];

    float ae,ap,as,aw,an,aj,bj,cj,ai,bi,ci;
    as=(1.0/pow(dy,2.0));
    aw=(1.0/pow(dx,2.0));  
    ap=-2.0*((1.0/pow(dx,2.0))+(1.0/pow(dy,2.0)));
    ae=(1.0/pow(dx,2.0));
    an=(1.0/pow(dy,2.0));
    ai=ap;                               //ai,bi,ci for x sweep
    bi=ae;
    ci=aw;
    aj=ap;                               //aj,bj,cj for y sweep
    bj=an;
    cj=as;
    p[0]=-bi/ai;
    q[0]=d[0]/ai;
    p2[0]=-(bj/aj);
    q2[0]=(d2[0])/aj;
 for(i=0;i<m;i++){
            for(j=0;j<n;j++){
                 if (i<=5 && j==0){
                    phi2[i][j]=0.0;                       //bottom boundary
                }
                else if (i>=6 && j==0){
                    phi2[i][j]=100.0;                    //bottom boundary
                }
                else if (j==(n-1)){
                    phi2[i][j]=0.0;                      //top boundary
                }
                else if (i==0){
                    phi2[i][j]=0.0;                         //left boundary
                }
                else{
                    phi2[i][j]=0.0;
                }
            }
        }
 //-----------------------------------------------ADI METHOD-------------------------------------------------------
                int iteration=0;
                float error=1.0;
                FILE *z;
                z=fopen("error1e.dat","w");
    do{


            for(i=0;i<m;i++){
                    for(j=0;j<n;j++){
               phi1[i][j]= phi2[i][j];
                    }
            }

            //:::::::::::::::::X-SWEEP:::::::::::::::::

            for(j=1;j<n-1;j++){
                d[0]=-an*(phi2[0][j+1]+phi2[0][j-1]);
                 for(i=1;i<m-1;i++){

                    d[i]=-an*(phi2[i][j+1]+phi2[i][j-1]);
                   p[i]=-(bi/(ai+ci*p[i-1]));
                   q[i]=(d[i]-ci*q[i-1])/(ai+ci*p[i-1]);

            }
            for(i=m-2;i>0;i--){
                phi2[i][j]=p[i]*phi2[i+1][j]+q[i];
            }
            }

            //:::::::::::::::::::::::::::::::Y-SWEEP::::::::::::::::::::::::

            for(i=1;i<m-1;i++){
              d2[0]=-ae*(phi2[i+1][0]+phi2[i-1][0]);

             for(j=1; j<n-1; j++){
                  d2[j]=-ae*(phi2[i+1][j]+phi2[i-1][j]);
                  p2[j]=-(bj/(aj+cj*p2[j-1]));
                  q2[j]=(d2[j]-cj*q2[j-1])/(aj+cj*p2[j-1]);

                  }

            for(j=n-2;j>0;j--){
                phi2[i][j]=p2[j]*phi2[i][j+1]+q2[j];

         }
    }
    for (j=0;j<n;j++){
        phi2[m-1][j]=phi2[m-2][j] ;
      }
      error=0.0;
       for(i=0;i<m;i++){
            for(j=0;j<n;j++){
            error=error+pow((phi2[i][j]-phi1[i][j]),2);
        }
    }
             iteration++ ;
      error=sqrt(error/((m-2)*(n-2)));
      printf("iteration %d\t\t",iteration);
      printf("error %.7f\n",error);
      fprintf(z,"%d\t%lf\n",iteration,error);
      }while(error > 1e-6);

 float x[m],y[n];
x[0]=0.0;y[0]=0.0;

for(j=0;j<n;j++){
 y[j+1]=y[j]+dy;
}
for(i=0;i<m;i++){
 x[i+1]=x[i]+dx;
}
FILE *y1;
y1=fopen("ADI.dat","w");
fprintf(y1,"Variable=\"X\",\"Y\",\"PSI\"\n",n,m);
fprintf(y1,"\tI=%d\tJ=%d\n",m,n);
for(i=0;i<m;i++) {
        for(j=0;j<n;j++){
    fprintf(y1,"%f\t\t%f\t\t%f\n",x[i],y[j],phi2[i][j]);
 }
} fclose(y1);

}
