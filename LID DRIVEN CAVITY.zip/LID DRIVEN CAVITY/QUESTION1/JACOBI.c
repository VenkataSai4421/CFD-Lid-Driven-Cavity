#include<stdio.h>
#include<stdlib.h>
#include<math.h>

void main(){

       int i,j,m=31,n=21;
       float psi_k[m][n];
       float x=6.0,y=4.0,dx,dy,b;
        float as,aw,ap,ae,an;


    dx=x/(m-1);
    dy=y/(n-1);
  b=pow((dx/dy),2);
    printf("b=%f\n",b);

    //boundary condition initialization
     for(int i=0; i<m ; i++){
        for(int j=0 ; j<n ; j++){

             if(i==0){
                psi_k[i][j]=0.0;
             }
            else if(j==0 && i<=5){
                psi_k[i][j]=0.0;
            }
            else if(j==0 && i>=6){
                psi_k[i][j]=100.0;
            }
            else if(j == n-1 ){
                psi_k[i][j]=0.0;
                }

            else{
                psi_k[i][j]=0.0;
            }
        }
    }



       //point gaus shiedel method
       float temp=0.0, error=1.0;
       int iteration=0;
       FILE *file1b;
       file1b=fopen("error1b.dat","w");
       do{
            error=0.0;

          for(int i=1;i<(m-1);i++)
        {
            for(int j=1;j<(n-1);j++)  {


           temp = psi_k[i][j];
           psi_k[i][j] = (1/(2*(1+b)))*(psi_k[i-1][j]+psi_k[i+1][j]+b*psi_k[i][j-1]+b*psi_k[i][j+1]);
           error= error + pow((psi_k[i][j]-temp),2.0);
        }
        }
        for(j=0;j<n;j++){
            psi_k[m-1][j]=psi_k[m-2][j];
        }

        error= sqrt(error/(m)*(n));
        iteration=iteration+1;
         printf("iteration %d\t",iteration);
      printf("error %f\n",error);
      fprintf(file1b,"%d\t%f\n",iteration,error);
      iteration++;
       } while (error > 1e-8);

FILE *file2;
    file2=fopen("Stream2.dat","w");
    fprintf(file2,"VARIABLES= \"X\",\"Y\",\"PHI\"\n");
    fprintf(file2, "ZONE t=\"BLOCK1\", J=31,I=21,F= POINT \n\n");

    for(int i=0; i<n ; i++){
            for(int j=0 ; j<m ; j++){
                fprintf(file2, "%lf \t %lf \t %lf \n",j*dy,i*dx,psi_k[j][i]);
            }
    }
}

